#ifndef PROJECTSELECT_H_
#define PROJECTSELECT_H_

#define PROJECT	1

#endif /* PROJECTSELECT_H_ */
